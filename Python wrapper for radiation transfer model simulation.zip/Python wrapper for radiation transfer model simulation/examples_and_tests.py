#!/usr/bin/env python
# # See if we are running this in ipython. If so, clear all variables from
# # memory and tell matplotlib to display all plots by default
# try:
#     __IPYTHON__
# except NameError:
#     INIPYTHON = False
# else:
#     from IPython import get_ipython
#     get_ipython().magic('reset -sf')
#     INIPYTHON = True
#     from matplotlib import interactive
#     interactive(True)
#     get_ipython().magic('matplotlib qt')
#     try:
#         get_ipython().magic('reload_ext autoreload')
#     except:
#         get_ipython().magic('load_ext autoreload')
#     get_ipython().magic('autoreload 2')
    
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

import lib.NFLRTMpy as NFLRTMpy

#import NFLRTMpy
# Close any existing plots
plt.close("all")

############################################################################

#--------------------------------------------------------------------------#
# Example/test #1: Tropical profile with marine aerosol and ice cloud
#--------------------------------------------------------------------------#
print(' ')
print('='*77)
print('TEST #1: Tropical profile with marine aerosol and ice cloud')

stnd_prof = 'TRP'       # Tropical standard profile for the pressure levels,
                        #                temperature, water vapor and ozone
sfc_albedo = 0.05       # Broadband surface albedo 
cos_solar_zenith = 0.5  # Cosine of the solar zenith angle

aer_H = 1.0             # Aerosol scale height [km]
aer_type = 'maritime'   # Aerosol type (1 -> d'Almedia Maritime)
aer_tau = 0.1           # Aerosol optical depth
aer_wavelength = 0.55   # Wavelength of aerosol optical depth [microns]

cld_fraction = 1.0      # Overcast cloud
cld_phase = 2.0         # Ice cloud
cld_base_pres = 300.0   # Cloud base pressure [mb]
cld_top_pres = 200.0    # Cloud top pressure [mb]
cld_tau = 1.0           # Cloud optical depth
cld_ice_diameter = 60.0 # Ice particle size (generalize effective) diameter [micron]

calc_noaer = True       # Do additional calculations with no aerosols in the
                        #         profile (for the aerosol radiative effect)
                        
flx, htr, ierror_in, ierror_out =\
                     NFLRTMpy.rt(stnd_prof, stnd_prof, stnd_prof, stnd_prof,
                                 sfc_albedo = sfc_albedo,
                                 cos_solar_zenith = cos_solar_zenith,
                                 aer_vertdist = aer_H,
                                 aer_type = aer_type,
                                 aer_tau = aer_tau,
                                 aer_wavelength = aer_wavelength,
                                 cld_fraction = cld_fraction,
                                 cld_phase = cld_phase,
                                 cld_base_pres = cld_base_pres,
                                 cld_top_pres = cld_top_pres,
                                 cld_tau = cld_tau,
                                 cld_ice_diameter = cld_ice_diameter,
                                 calc_noaer = calc_noaer)
                                 
# Cloud and aerosol radiative effects on the TOA flux
val = np.array([\
                flx['swup_toa'][0] - flx['swup_toa'][1],
                flx['swup_toa'][0] - flx['swup_toa'][2],     
                flx['lwup_toa'][0] - flx['lwup_toa'][1],
                flx['lwup_toa'][0] - flx['lwup_toa'][2]])
                
test_val = np.array([ 79.64020474,   5.57536555, -73.03656219,  -0.36008842])

np.testing.assert_almost_equal(val, test_val, decimal=8, verbose=True,
                               err_msg='TEST #1 FAILED')
                               
stop                               
print('Reflected SW cloud radiative effect = ',val[0])
print('Reflected SW aerosol radiative effect = ',val[1])
print('Outgoing LW cloud radiative effect = ',val[2])
print('Outgoing LW aerosol radiative effect = ',val[3])

print(' ')
print('TEST #1 PASSED')

#--------------------------------------------------------------------------#
# Example/test #2: Midlatitude summer domain with 3 clouds
#--------------------------------------------------------------------------#
print(' ')
print('='*77)
print('TEST #2: Midtlaitude summer profile with 3 clouds')

stnd_prof = 'MLS'       # Midlatitude summer profile for the pressure levels,
                        #                temperature, water vapor and ozone
sfc_albedo = 0.1        # Broadband surface albedo 
cos_solar_zenith = 0.6  # Cosine of the solar zenith angle

# 2 cloud non-overlapping cloud conditions with total cloud fraction of 75%:
cld_fraction = np.array([0.50, 0.25]) 

# Numpy arrays for cloud inputs: [layer, non-overlapping conditions]
cld_base_pres = np.zeros([2,2])  # zeros = no cloud
cld_top_pres = np.zeros([2,2])
cld_phase = np.zeros([2,2])
cld_tau = np.zeros([2,2])
cld_ice_diameter = np.zeros([2,2])
cld_liquid_radius = np.zeros([2,2])

# The first cloud condition consistents of 2 overlapping cloud layers
cld_base_pres[0,0] = 1000.0   # Cloud base pressure [mb]
cld_top_pres[0,0] = 894.0     # Cloud top pressure [mb]
cld_phase[0,0] = 1.0          # Liquid cloud
cld_tau[0,0] = 5.0            # Optical depth 
cld_liquid_radius[0,0] = 7.9  # Liquid particle effective radius [micron] 

cld_base_pres[1,0] = 501.0    # Cloud base pressure [mb]
cld_top_pres[1,0] = 449.0     # Cloud top pressure [mb]
cld_phase[1,0] = 1.5          # Mixed-phased cloud: half liquid, half ice
cld_tau[1,0] = 2.0            # Optical depth
cld_liquid_radius[1,0] = 13.5 # Liquid particle effective radius [micron]
cld_ice_diameter[1,0] = 30.1  # Ice particle size (generalize effective) diameter [micron]

# The second cloud condition is a single layer cloud
cld_base_pres[0,1] = 205.0    # Cloud base pressure [mb]
cld_top_pres[0,1] = 151.0     # Cloud top pressure [mb]
cld_phase[0,1] = 2.0          # Ice cloud
cld_tau[0,1] = 0.1            # Optical depth
cld_ice_diameter[0,1] = 53.1  # Ice particle size (generalize effective) diameter [micron]

flx, htr, ierror_in, ierror_out =\
                      NFLRTMpy.rt(stnd_prof, stnd_prof, stnd_prof, stnd_prof,
                                  sfc_albedo = sfc_albedo,
                                  cos_solar_zenith = cos_solar_zenith,
                                  cld_fraction = cld_fraction,
                                  cld_phase = cld_phase,
                                  cld_base_pres = cld_base_pres,
                                  cld_top_pres = cld_top_pres,
                                  cld_tau = cld_tau,
                                  cld_liquid_radius = cld_liquid_radius,
                                  cld_ice_diameter = cld_ice_diameter,
                                  calc_noaer = calc_noaer)
                               
# Cloud and aerosol radiative effects on the TOA flux
val = np.array([\
       flx['swup_toa'][0] - flx['swup_toa'][1],
       flx['swup_toa'][0] - flx['swup_toa'][2],     
       flx['lwup_toa'][0] - flx['lwup_toa'][1],
       flx['lwup_toa'][0] - flx['lwup_toa'][2]])
       
test_val = np.array([  1.20897898e+02,   4.72905981e-09,  -3.04258744e+01,
        -7.27027327e-11])
        
np.testing.assert_almost_equal(val, test_val, decimal=6, verbose=True,
                               err_msg='TEST #2 FAILED')
                               
print('Reflected SW cloud radiative effect = ',val[0])
print('Reflected SW aerosol radiative effect = ',val[1])
print('Outgoing LW cloud radiative effect = ',val[2])
print('Outgoing LW aerosol radiative effect = ',val[3])


# Plot heating rate profile
pres = NFLRTMpy.standard_profiles(stnd_prof)[:,0] #[mb]
pres_lyr = np.exp(NFLRTMpy.lvl2lyr(np.log(pres)))

fig = plt.figure()

ax = fig.add_subplot(1,2,1)
plt.plot(htr['sw'][0,:], pres_lyr,'r', label='SW')
plt.plot(htr['lw'][0,:], pres_lyr,'b', label='LW')
plt.plot(htr['sw'][0,:]+htr['lw'][0,:], pres_lyr,'k', label='NET')
plt.ylim(pres.max(), 1)
ax.set_yscale('log')
ax.yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%d'))
plt.ylabel('Pressure [mb]')
plt.xlabel('Heating rate [K/day]')
plt.title('TEST #2')

ax = fig.add_subplot(1,2,2)
plt.plot(htr['sw'][0,:]-htr['sw'][1,:], pres_lyr,'r', label='SW')
plt.plot(htr['lw'][0,:]-htr['lw'][1,:], pres_lyr,'b', label='LW')
plt.plot( (htr['sw'][0,:]+htr['lw'][0,:]) -\
          (htr['sw'][1,:]+htr['lw'][1,:]), pres_lyr,'k', label='NET')
plt.ylim(pres.max(), 1)
ax.set_yscale('log')
ax.yaxis.set_major_formatter(mpl.ticker.FormatStrFormatter('%d'))
plt.ylabel('Pressure [mb]')
plt.xlabel('Cloud radiative effect [K/day]')
plt.legend(loc='upper right')
plt.title('TEST #2')

print(' ')
print('TEST #2 PASSED')

#--------------------------------------------------------------------------#
# Example/test #3: Sub-Arctic winter pristine profile: 2x CO2
#--------------------------------------------------------------------------#

print(' ')
print('='*77)
print('TEST #3: Sub-arctic winter pristine profile')

# Sub-arctic winter profile: sub-sample levels
X = NFLRTMpy.standard_profiles('SAW')
X = X[0:-1:2,:]
pres = X[:,0]        # Pressure [mb]
temp = X[:,1]        # Temperature [K]
water_vapor = X[:,2] # Water vapor [g/g]
ozone = X[:,3]       # Ozone [g/g]

sfc_albedo = 0.25       # Broadband surface albedo 
cos_solar_zenith = 0.5  # Cosine of the solar zenith angle

# Adds surface values
sfc_pressure = 1020.0     # Surface pressure [mb]
sfc_temperature  = 252.1  # Surface temperature [K]
sfc_water_vapor = 9.0E-4  # Surface water vapor [g/g]
sfc_ozone = 3.0E-8        # Surface ozone [g/g]
skin_temperature = 251.0  # Skin temperature [K]

# Pre-industrial CO2
co2 = 280.0

flx_pre, htr_pre, ierror_in, ierror_out =\
                      NFLRTMpy.rt(pres, temp, water_vapor, ozone,
                                  sfc_albedo = sfc_albedo,
                                  sfc_pressure = sfc_pressure,
                                  sfc_temperature  = sfc_temperature,
                                  sfc_water_vapor = sfc_water_vapor,
                                  sfc_ozone = sfc_ozone,
                                  skin_temperature = skin_temperature,
                                  cos_solar_zenith = cos_solar_zenith,
                                  co2 = co2,
                                  out_flux_spectral = True)
                                  
# 2x CO2
co2 = 2.0 * co2

flx, htr, ierror_in, ierror_out =\
                      NFLRTMpy.rt(pres, temp, water_vapor, ozone,
                                  sfc_albedo = sfc_albedo,
                                  sfc_pressure = sfc_pressure,
                                  sfc_temperature  = sfc_temperature,
                                  sfc_water_vapor = sfc_water_vapor,
                                  sfc_ozone = sfc_ozone,
                                  skin_temperature = skin_temperature,
                                  cos_solar_zenith = cos_solar_zenith,
                                  co2 = co2,
                                  out_flux_spectral = True)
                                  
# Effect on OLR
x = flx['lwup_toa'][0] - flx_pre['lwup_toa'][0]

np.testing.assert_almost_equal(x, -1.7022891354063461, decimal=8, verbose=True,
                               err_msg='TEST #3 FAILED')
                               
print(' ')
print('Change in OLR from 2x CO2 = ',x)


# LW spectral flux change
x = flx['spectral_lwup_toa'][0,:] - flx_pre['spectral_lwup_toa'][0,:]

test_val = np.array([ 0.,  0.,  0.,  0.,  0.,
                      -0.0054347 , -0.00693897, -0.80852449, -0.88139097,
                      0., 0., 0., 0., 0.])
                      
np.testing.assert_almost_equal(x, test_val, decimal=6, verbose=True,
                               err_msg='TEST #3 FAILED')
                               
                               
print(' ')
print('Change in SPECTRAL OLR from 2x CO2')
print('\n'.join(['Band {:>2d}: {:>8.3f}'.format(c+1,x)\
                 for c,x in enumerate(x)]))
                 
print(' ')
print('TEST #3 PASSED')


#**************************************************************************
#**************************************************************************
#**************************************************************************

