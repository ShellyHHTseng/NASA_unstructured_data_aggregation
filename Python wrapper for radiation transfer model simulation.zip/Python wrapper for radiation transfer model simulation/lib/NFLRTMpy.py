"""
Provides an interface to the NASA Fu-Liou Radiative Transfer Model (NFLRTM)

"""    
import numpy as np
import warnings
import glob

#from lib import NFLRTM


#############################################################################

def standard_profiles(prof):
    '''
    Standard profiles 
    
    '''
    prof = prof.lower()
    
    #-----------------------------------#
    # Mid-latitude summer
    if prof in ['mls']:
        X = [\
             [1.0000000E-03,   210.0000, 1.2056529E-06,  2.5921537E-08],
             [6.7000002E-02,   218.0000, 2.5031650E-06,  8.0325441E-07],
             [0.9510000,  276.0000, 3.1658121E-06,  3.5823662E-06],
             [1.760000,  270.0000, 3.0958465E-06,  5.7248940E-06],
             [3.330000,  258.0000, 2.9580133E-06,  9.1186866E-06],
             [6.520000,  245.0000, 2.8153472E-06,  9.9238287E-06],
             [13.20000,  234.0000, 2.6919724E-06,  1.0177589E-05],
             [27.70000,  224.0000, 3.9927277E-06,  6.9640605E-06],
             [32.20000,  223.0000, 3.9959314E-06,  6.3616812E-06],
             [37.60000,  222.0000, 3.9829611E-06,  5.7625816E-06],
             [43.70000,  220.0000, 3.9741744E-06,  5.2025557E-06],
             [51.00000,  219.0000, 3.9691986E-06,  4.4376134E-06],
             [59.50000,  218.0000, 3.9756146E-06,  3.5759494E-06],
             [69.50000,  217.0000, 3.9795218E-06,  2.8681236E-06],
             [81.20000,  216.0000, 3.9860361E-06,  2.1381036E-06],
             [95.00000,  216.0000, 4.0074806E-06,  1.5664418E-06],
             [111.0000,  216.0000, 4.0163600E-06,  1.1730676E-06],
             [130.0000,  216.0000, 4.0160166E-06,  9.0622694E-07],
             [153.0000,  216.0000, 4.0323516E-06,  7.2947068E-07],
             [179.0000,  216.0000, 5.7501838E-06,  5.1959501E-07],
             [209.0000,  222.0000, 1.9697549E-05,  3.6589873E-07],
             [243.0000,  229.0000, 5.9244263E-05,  2.9757393E-07],
             [281.0000,  235.0000, 1.5436381E-04,  2.1606132E-07],
             [324.0000,  242.0000, 2.5300283E-04,  1.8439189E-07],
             [372.0000,  248.0000, 4.0188432E-04,  1.5118506E-07],
             [426.0000,  255.0000, 6.3749601E-04,  1.2887388E-07],
             [487.0000,  261.0000, 9.3691860E-04,  1.0615334E-07],
             [554.0000,  267.0000, 1.3834850E-03,  9.1310014E-08],
             [628.0000,  273.0000, 2.3585104E-03,  7.9864904E-08],
             [710.0000,  279.0000, 3.8691266E-03,  6.9937563E-08],
             [802.0000,  285.0000, 5.9675951E-03,  6.1206102E-08],
             [902.0000,  290.0000, 8.5831638E-03,  5.5375246E-08],
             [1013.000,  294.0000, 1.1663768E-02,  4.9987573E-08]]
    
    
    #-----------------------------------#
    # Sub-artic summer
    elif prof in ['sas']:
        X = [\
             [1.0000000E-03,   210.0000, 1.2056529E-06,  2.5921537E-08],
             [7.1000002E-02,   216.0000, 2.4714666E-06,  7.5104640E-07],
             [0.9870000,  277.0000, 3.1822383E-06,  3.4642089E-06],
             [1.810000,  274.0000, 3.1592162E-06,  5.6492172E-06],
             [3.400000,  262.0000, 3.0083906E-06,  9.0694130E-06],
             [6.610000,  247.0000, 2.8425909E-06,  9.8686178E-06],
             [13.40000,  235.0000, 2.6933321E-06,  7.0479718E-06],
             [27.80000,  228.0000, 4.0023210E-06,  6.1211967E-06],
             [32.27000,  226.0000, 4.0006958E-06,  5.6291201E-06],
             [37.50000,  225.0000, 3.9958782E-06,  5.1670841E-06],
             [43.60000,  225.0000, 3.9997494E-06,  4.7404433E-06],
             [50.70000,  225.0000, 4.0001587E-06,  4.5861689E-06],
             [58.90000,  225.0000, 4.0025161E-06, 4.2766610E-06],
             [68.60000,  225.0000, 4.0767991E-06, 3.8602489E-06],
             [79.80000,  225.0000, 3.9983379E-06,  3.3184590E-06],
             [92.80000,  225.0000, 3.9950237E-06,  2.7143890E-06],
             [108.0100,  225.0000, 3.9945512E-06,  2.0331547E-06],
             [125.0000,  225.0000, 4.0148238E-06,  1.6534667E-06],
             [146.0000,  225.0000, 4.5123497E-06,  1.2386844E-06],
             [170.0000,  225.0000, 7.8266130E-06,  9.8782482E-07],
             [197.7000,  225.0000, 1.3721391E-05,  6.8606954E-07],
             [230.0000,  225.0000, 2.4038169E-05,  5.0547555E-07],
             [267.7000,  225.0000, 4.2222615E-05,  3.1365371E-07],
             [310.7000,  232.0000, 8.9597510E-05,  2.3578293E-07],
             [359.0000,  239.0000, 2.4843903E-04,  1.5097450E-07],
             [413.0000,  246.0000, 4.9585645E-04,  1.2823875E-07],
             [473.0000,  253.0000, 8.3374296E-04,  1.0901612E-07],
             [541.0000,  260.0000, 1.3423382E-03,  8.8293568E-08],
             [616.0000,  266.0000, 2.0453040E-03,  7.4374690E-08],
             [700.0000,  271.0000, 2.9894868E-03,  6.4457332E-08],
             [792.9000,  276.0000, 4.1967481E-03,  5.5956647E-08],
             [896.0000,  282.0000, 5.4208240E-03,  4.8787420E-08],
             [1010.000,  287.0000, 7.4229222E-03,  3.9969578E-08]]
   
   
   #-----------------------------------#
   # Tropical
    elif prof in ['trp','trop']:
       X = [\
            [1.0000000E-03,   210.0000, 9.8260716E-07,  2.5921537E-08],
            [5.7999998E-02,   219.0000, 3.2408605E-06,  9.3215385E-07],
            [0.8540000,  270.0000, 3.2490914E-06,  3.9025399E-06],
            [1.590000,  265.0000, 3.2629177E-06,  6.2196377E-06],
            [3.050000,  254.0000, 3.2512157E-06,  9.8014589E-06],
            [6.000000,  243.0000, 3.2552625E-06,  1.0695862E-05],
            [12.20000,  232.0000, 3.2480157E-06,  1.3101239E-05],
            [25.70000,  221.0000, 3.2337271E-06,  8.3928808E-06],
            [30.00000,  219.0000, 3.2480866E-06,  7.1248351E-06],
            [35.00000,  217.0000, 3.2569853E-06,  5.6952745E-06],
            [40.90000,  215.0000, 3.2594312E-06,  4.2251886E-06],
            [48.00000,  211.0000, 3.2556216E-06,  3.0284850E-06],
            [56.50000,  207.0000, 3.2497753E-06,  1.9982438E-06],
            [66.60000,  203.0000, 3.2549005E-06,  1.2249626E-06],
            [78.90000,  199.0000, 3.2508381E-06,  6.5161566E-07],
            [93.70000,  195.0000, 3.2558512E-06,  4.1220866E-07],
            [111.0000,  197.0000, 3.2453061E-06,  2.3944958E-07],
            [132.0000,  204.0000, 3.3583428E-06,  2.0851007E-07],
            [156.0000,  210.0000, 3.8101723E-06,  1.7389223E-07],
            [182.0000,  217.0000, 6.1265282E-06, 1.5401888E-07],
            [213.0000,  224.0000, 1.8354602E-05,  1.2981052E-07],
            [247.0000,  230.0000, 4.7847239E-05,  1.0959423E-07],
            [286.0000,  237.0000, 1.1656049E-04,  9.2772630E-08],
            [329.0000,  244.0000, 2.5760382E-04,  8.3029327E-08],
            [378.0000,  250.0000, 4.7463647E-04,  7.4043285E-08],
            [432.0000,  257.0000, 8.0434664E-04,  7.0017435E-08],
            [492.0000,  264.0000, 1.3246776E-03,  6.6233888E-08],
            [559.0000,  270.0000, 2.1213696E-03,  6.2393227E-08],
            [633.0000,  277.0000, 3.3414173E-03,  5.9040079E-08],
            [715.0000,  284.0000, 5.3589917E-03,  5.8150764E-08],
            [805.0000,  288.0000, 9.5408112E-03,  5.5457889E-08],
            [904.0000,  294.0000, 1.2136549E-02,  5.2280523E-08],
            [1013.000,  300.0000, 1.6152449E-02,  4.7607219E-08]]
      
   #-----------------------------------#
   # Mid-latitude winter
    elif prof in ['mlw']:
       X = [\
            [1.0000000E-03,   210.2000, 1.2068010E-06,  2.5946223E-08],
            [4.6999998E-02,   230.7000, 3.9734873E-06,  1.2117728E-06],
            [0.6820000,  265.7000, 4.0037157E-06,  4.8089319E-06],
            [1.290000,  258.5000, 4.0036221E-06,  7.4780287E-06],
            [2.530000,  243.2000, 4.0011428E-06,  1.1313575E-05],
            [5.180000,  227.8000, 4.0018085E-06,  1.1614080E-05],
            [11.10000,  217.4000, 4.0086579E-06,  1.0682259E-05],
            [24.30000,  215.2000, 4.0166692E-06,  8.6434657E-06],
            [28.60000,  215.2000, 3.9959587E-06,  7.7759196E-06],
            [33.40000,  215.2000, 4.0135487E-06,  7.2132902E-06],
            [39.10000,  215.2000, 4.0130276E-06,  6.7937081E-06],
            [45.80000,  215.2000, 4.0059563E-06,  5.7998691E-06],
            [53.70000,  215.2000, 4.0033187E-06,  5.1767051E-06],
            [62.80000,  215.2000, 4.0035943E-06,  4.2298416E-06],
            [73.50000,  215.7000, 4.0015607E-06,  3.4539787E-06],
            [86.10000,  216.2000, 4.0005384E-06,  2.8111892E-06],
            [100.7000,  216.7000, 4.0029249E-06,  2.2238471E-06],
            [117.8000,  217.2000, 4.0437176E-06,  1.7995602E-06],
            [137.8000,  217.7000, 5.1246070E-06,  1.4512162E-06],
            [161.0000,  218.2000, 6.6916045E-06,  1.1671405E-06],
            [188.2000,  218.7000, 9.0734193E-06,  8.6731217E-07],
            [219.9000,  219.2000, 1.2704899E-05,  6.0090741E-07],
            [256.8000,  219.7000, 1.8419141E-05,  3.9294164E-07],
            [299.2000,  225.7000, 3.4646786E-05,  2.5985085E-07],
            [347.3000,  231.7000, 6.7028923E-05,  1.7236009E-07],
            [401.6000,  237.7000, 1.4560936E-04,  1.3082754E-07],
            [462.7000,  243.7000, 2.8575296E-04,  9.6762918E-08],
            [531.3000,  249.7000, 5.0996867E-04,  7.8249165E-08],
            [608.1000,  255.7000, 8.3287113E-04,  5.9145922E-08],
            [693.8000,  261.7000, 1.2560310E-03,  5.3056485E-08],
            [789.7000,  265.2000, 1.7352295E-03,  4.7236803E-08],
            [897.3000,  268.7000, 2.1490329E-03,  4.6419107E-08],
            [1018.000,  272.2000, 2.6864663E-03,  4.6053703E-08]]
           
   #-----------------------------------#
   # Sub-artic winter
    elif prof in ['saw']:
       X = [\
            [1.0000000E-03,   210.0000, 1.2056529E-06,  2.5921537E-08],
            [3.9999999E-02,   245.7000, 4.0202499E-06,  1.5164100E-06],
            [0.5720000,  259.3000, 3.9950096E-06,  5.5956161E-06],
            [1.113000,  247.0000, 4.0006857E-06,  8.2816741E-06],
            [2.243000,  234.7000, 3.9949232E-06,  1.2315176E-05],
            [4.701000,  222.2000, 4.0026612E-06,  1.2482875E-05],
            [10.20000,  216.0000, 3.9999300E-06,  9.1183829E-06],
            [22.56000,  211.2000, 4.0041837E-06,  8.5995889E-06],
            [26.49000,  211.8000, 3.9936158E-06,  8.2626539E-06],
            [31.09000,  212.4000, 4.0007085E-06,  8.4328658E-06],
            [36.47000,  213.0000, 4.0069572E-06,  7.8797902E-06],
            [42.77000,  213.6000, 3.9998085E-06,  7.3114779E-06],
            [50.14000,  214.1000, 3.9959768E-06,  6.8642548E-06],
            [58.75000,  214.8000, 3.9987508E-06,  6.2972463E-06],
            [68.82000,  215.4000, 3.9981956E-06,  5.5705191E-06],
            [80.58000,  216.0000, 4.0013156E-06,  4.7707995E-06],
            [94.31000,  216.6000, 4.0018649E-06,  4.0875721E-06],
            [110.3000,  217.2000, 4.1434419E-06,  3.1655218E-06],
            [129.1000,  217.2000, 5.3125027E-06,  2.3664786E-06],
            [151.0000,  217.2000, 6.8956037E-06,  1.9406789E-06],
            [176.6000,  217.2000, 9.1088132E-06,  1.5181354E-06],
            [206.7000,  217.2000, 1.1432246E-05,  9.6525548E-07],
            [241.8000,  217.2000, 1.4207842E-05,  6.1885328E-07],
            [282.9000,  217.2000, 1.8446981E-05,  3.5263042E-07],
            [330.8000,  220.6000, 2.5268939E-05,  1.7228822E-07],
            [385.3000,  227.3000, 5.5714645E-05,  1.2023524E-07],
            [446.7000,  234.1000, 1.4712867E-04,  7.3714773E-08],
            [515.8000,  240.9000, 3.1372151E-04,  6.3012443E-08],
            [593.2000,  247.7000, 5.5018719E-04,  5.3939925E-08],
            [679.8000,  252.7000, 7.9710892E-04,  4.5884452E-08],
            [777.5000,  255.9000, 9.7315072E-04,  3.8737067E-08],
            [887.8000,  259.1000, 1.0053251E-03,  3.4348606E-08],
            [1013.000,  257.1000, 8.7427255E-04,  2.9870975E-08]]
            
    #-----------------------------------#
    else:
       raise ValueError('Unknown standard atmosphere: '+prof)
       
       
    return np.array(X)[::-1,:]
    
    
#############################################################################
def satvap(temp2):
    '''
    Returns the saturation vapor pressure [mb] for a given temperature [K]
    
    '''
    import numpy as np    
    
    temp = temp2-273.155;
    
    satvap = np.zeros_like(temp)
    
    icei = temp<0
    vapori = temp>=0
    
    # Ice saturation
    toot = 273.16 / temp2
    toto = 1 / toot
    eilog = -9.09718 * (toot - 1) - 3.56654 *\
            ( np.log(toot) / np.log(10.)) + .876793 * (1 - toto) +\
            (np.log(6.1071) / np.log(10.))
    satvap[icei] = 10**eilog[icei]
    
    # Vapor saturation
    tsot = 373.16 / temp2
    ewlog = -7.90298 * (tsot - 1) + 5.02808 * (np.log(tsot) / np.log(10.))
    ewlog2 = ewlog - 1.3816e-07 * (10 ** (11.344 * (1 - (1 / tsot))) - 1)
    ewlog3 = ewlog2 + .0081328 * (10 ** (-3.49149 * (tsot - 1)) - 1)
    ewlog4 = ewlog3 + (np.log(1013.246) / np.log(10.))
    satvap[vapori] = 10**ewlog4[vapori]
    
    return satvap
    
def emissivity_igbp(igbp):

    emiss_str = ['evergreen needle',
                 'evergreen broad',
                 'deciduous needle',
                 'deciduous broad',
                 'mixed forest',
                 'closed shrubs',
                 'open shrubs',
                 'woody savanna',
                 'savanna',
                 'grassland',
                 'wetland',
                 'cropland',
                 'urban',
                 'crop mosaic',
                 'snow',
                 'desert',
                 'water',
                 'tundra',
                 'fresh snow',
                 'sea ice']
    
    emisstbl = np.array([\
       [0.989, 0.989, 0.990, 0.991, 0.991, 0.990,
       0.990, 0.995, 1.000, 1.000, 1.000, 1.000],   #(1) everg
       [0.989, 0.989, 0.990, 0.991, 0.991, 0.990,
       0.990, 0.995, 1.000, 1.000, 1.000, 1.000],   #(2) everg           
       [0.985, 0.986, 0.984, 0.983, 0.979, 0.980,  
       0.973, 0.987, 1.000, 1.000, 1.000, 1.000],   #(3) decid           
       [0.985, 0.986, 0.984, 0.983, 0.979, 0.980,  
       0.973, 0.987, 1.000, 1.000, 1.000, 1.000],   #(4) decid           
       [0.987, 0.987, 0.987, 0.987, 0.985, 0.985,  
       0.982, 0.991, 1.000, 1.000, 1.000, 1.000],   #(5) mixed           
       [0.949, 0.970, 0.974, 0.971, 0.947, 0.958,  
       0.966, 0.975, 0.984, 0.984, 0.984, 0.984],   #(6) close           
       [0.873, 0.934, 0.944, 0.939, 0.873, 0.904,  
       0.936, 0.942, 0.951, 0.951, 0.951, 0.951],   #(7) open            
       [0.987, 0.990, 0.992, 0.993, 0.983, 0.975,  
       0.985, 0.993, 1.000, 1.000, 1.000, 1.000],   #(8) woody           
       [0.987, 0.990, 0.992, 0.993, 0.983, 0.975,  
       0.985, 0.993, 1.000, 1.000, 1.000, 1.000],   #(9) savan           
       [0.987, 0.990, 0.992, 0.993, 0.983, 0.975,  
       0.985, 0.993, 1.000, 1.000, 1.000, 1.000],   #(10) grass           
       [0.983, 0.987, 0.987, 0.988, 0.983, 0.981,  
       0.987, 0.982, 0.986, 0.986, 0.986, 0.986],   #(11) perma           
       [0.987, 0.990, 0.992, 0.993, 0.983, 0.975,  
       0.985, 0.993, 1.000, 1.000, 1.000, 1.000],   #(12) cropl           
       [1.000, 1.000, 1.000, 1.000, 1.000, 1.000,  
       1.000, 1.000, 1.000, 1.000, 1.000, 1.000],   #(13) urban           
       [0.987, 0.989, 0.989, 0.990, 0.984, 0.980,  
       0.983, 0.992, 1.000, 1.000, 1.000, 1.000],   #(14) mosai           
       [1.000, 1.000, 1.000, 1.000, 1.000, 1.000,  
       1.000, 0.999, 0.999, 0.999, 0.999, 0.999],   #(15) snow            
       [0.835, 0.916, 0.934, 0.923, 0.835, 0.877,  
       0.921, 0.926, 0.934, 0.934, 0.934, 0.934],   #(16) barre           
       [0.979, 0.983, 0.982, 0.982, 0.984, 0.987,  
       0.989, 0.972, 0.972, 0.972, 0.972, 0.972],   #(17) water           
       [0.947, 0.967, 0.988, 0.979, 0.975, 0.977,  
       0.992, 0.989, 0.989, 0.989, 0.989, 0.989],   #(18) tundr           
       [0.988, 0.988, 0.988, 0.988, 0.988, 0.988,  
       0.988, 0.988, 0.988, 0.988, 0.988, 0.988],   #(19) FRESH SNOW
       [0.979, 0.979, 0.979, 0.979, 0.979, 0.979,  
        0.979, 0.979, 0.979, 0.979, 0.979, 0.979]])  #(20) SEA ICE
        
    if isinstance(igbp, str):
        x = emisstbl[emiss_str.index(igbp.lower()),:]
    else:
        x = emisstbl[igbp-1,:]
        
    # Use band 1 for the 2 hidden bands
    x = np.append(x, [x[0], x[0]])
    
    return x
    
#############################################################################
def mix2rh(mix,temp,pres):
    #
    # Convert mass mixing ratio [g/g] to RH [%]
    #
    # RH [%] 
    # temp: temperature [K]
    # pres: pressure [mb]
    
    es = satvap(temp)
    A = 0.622E-2 * (es/ (pres -es) )
    rh = mix/A
    
    return rh
    
#############################################################################
def wrapTo360(lon):
    #wrapTo360 Wrap angle in degrees to [0 360]
    #
    #   lonWrapped = wrapTo360(LON) wraps angles in LON, in degrees, to the
    #   interval [0 360] such that zero maps to zero and 360 maps to 360.
    #   (In general, positive multiples of 360 map to 360 and negative
    #     multiples of 360 map to zero.)
    positiveInput = (lon > 0)
    lon = lon % 360.0
    try:
        lon[ (lon == 0) & positiveInput] = 360.0
    except:
        if (lon == 0) & positiveInput:
            lon = 360.0
        
    return lon
    
#############################################################################
def wrapTo180(lon):
    #wrapTo180 Wrap angle in degrees to [-180 180]
    #
    #   lonWrapped = wrapTo180(LON) wraps angles in LON, in degrees, to the
    #   interval [-180 180] such that 180 maps to 180 and -180 maps to -180.
    #   (In general, odd, positive multiples of 180 map to 180 and odd,
    #    negative multiples of 180 map to -180.)
    try:
        q = (lon < -180.0) | (180.0 < lon)
        lon[q] = wrapTo360(lon[q] + 180.0) - 180.0
    except:
        if (lon < -180.0) | (180.0 < lon):
            lon = wrapTo360(lon + 180.0) - 180.0
            
        
    return lon
    
#############################################################################
def lvl2lyr(X):
    return (X[1:] + X[:-1]) / 2.0    
    
#############################################################################
def earthsun_dist(time, Alt=100.0):
    # Return Earth sun distance in AU
    # Alt is km (default it at TOA, i.e. 100km)
    # datetime object
    
    # datetime object -> UNIX time
    if isinstance(time, list):
        utime = np.array([np.float64(x.strftime('%s')) for x in time])
    else:
        utime = np.float64(time.strftime('%s'))
    
    # Julian time
    jd = (utime / 86400.0) + 2440587.5
    d = jd-2451543.5
    
    # Keplerian Elements for the Sun (geocentric)
    w = 282.9404+4.70935e-5*d  #(longitude of perihelion degrees)
    e = 0.016709-1.151e-9*d    #(eccentricity)
    M = np.mod(356.0470+0.9856002585*d,360) #(mean anomaly degrees)
    oblecl = 23.4393-3.563e-7*d   #(Sun's obliquity of the ecliptic)
    
    #auxiliary angle
    E = M+(180.0/np.pi)*e*np.sin(M*(np.pi/180.0))*(1+e*np.cos(M*(np.pi/180.0)))
    
    #rectangular coordinates in the plane of the ecliptic (x axis toward
                                                           #perhilion)
    x = np.cos(E*(np.pi/180.0))-e
    y = np.sin(E*(np.pi/180.0))*np.sqrt(1-e**2)
    
    #find the distance and true anomaly
    r = np.sqrt(x**2 + y**2)
    v = np.arctan2(y,x)*(180.0/np.pi)
    
    #find the longitude of the sun
    lon = v + w
    
    #compute the ecliptic rectangular coordinates
    xeclip = r*np.cos(lon*(np.pi/180.0))
    yeclip = r*np.sin(lon*(np.pi/180.0))
    zeclip = 0.0
    
    #rotate these coordinates to equitorial rectangular coordinates
    xequat = xeclip
    yequat = yeclip*np.cos(oblecl*(np.pi/180.0))+zeclip*np.sin(oblecl*(np.pi/180.0))
    zequat = yeclip*np.sin(23.4406*(np.pi/180.0))+zeclip*np.cos(oblecl*(np.pi/180.0))
    
    #convert equatorial rectangular coordinates to RA and Decl:
    es_dist = np.sqrt(xequat**2 + yequat**2 + zequat**2)-(Alt/149598000) #roll up the altitude correction
    
    return es_dist
    
#############################################################################
def solar_pos(time, Lat, Lon, Alt=100.0):
    # Alt is km (default it at TOA, i.e. 100km)
    # datetime object
    
    # datetime object -> UNIX time
    if isinstance(time, list):
        utime = np.array([np.float64(x.strftime('%s')) for x in time])
        utime_day = np.array([np.float64(x.date().strftime('%s')) for x in time])
    else:
        utime = np.float64(time.strftime('%s'))
        utime_day = np.float64(time.date().strftime('%s'))
        
    
    # Julian time
    jd = (utime / 86400.0) + 2440587.5
    d = jd-2451543.5
        
    # Keplerian Elements for the Sun (geocentric)
    w = 282.9404+4.70935e-5*d  #(longitude of perihelion degrees)
    e = 0.016709-1.151e-9*d    #(eccentricity)
    M = np.mod(356.0470+0.9856002585*d,360) #(mean anomaly degrees)
    L = w + M                     #(Sun's mean longitude degrees)
    oblecl = 23.4393-3.563e-7*d   #(Sun's obliquity of the ecliptic)
    
    #auxiliary angle
    E = M+(180.0/np.pi)*e*np.sin(M*(np.pi/180.0))*(1+e*np.cos(M*(np.pi/180.0)))
    
    #rectangular coordinates in the plane of the ecliptic (x axis toward
                                                           #perhilion)
    x = np.cos(E*(np.pi/180.0))-e
    y = np.sin(E*(np.pi/180.0))*np.sqrt(1-e**2)
    
    #find the distance and true anomaly
    r = np.sqrt(x**2 + y**2)
    v = np.arctan2(y,x)*(180.0/np.pi)
    
    #find the longitude of the sun
    lon = v + w
    
    #compute the ecliptic rectangular coordinates
    xeclip = r*np.cos(lon*(np.pi/180.0))
    yeclip = r*np.sin(lon*(np.pi/180.0))
    zeclip = 0.0
    
    #rotate these coordinates to equitorial rectangular coordinates
    xequat = xeclip
    yequat = yeclip*np.cos(oblecl*(np.pi/180.0))+zeclip*np.sin(oblecl*(np.pi/180.0))
    zequat = yeclip*np.sin(23.4406*(np.pi/180.0))+zeclip*np.cos(oblecl*(np.pi/180.0))
    
    #convert equatorial rectangular coordinates to RA and Decl:
    es_dist = np.sqrt(xequat**2 + yequat**2 + zequat**2)-(Alt/149598000) #roll up the altitude correction
    RA = np.arctan2(yequat,xequat)*(180.0/np.pi)
    delta = np.arcsin(zequat/es_dist)*(180.0/np.pi)
    
    # Calculate local siderial time
    Lon = wrapTo180(Lon)        
    UTH = (utime - utime_day) / 3600.0
    GMST0=np.mod(L+180,360)/15
    SIDTIME = GMST0 + UTH + Lon/15
    
    # Replace RA with hour angle HA
    HA = (SIDTIME*15 - RA)
    
    # convert to rectangular coordinate system
    x = np.cos(HA*(np.pi/180))*np.cos(delta*(np.pi/180))
    y = np.sin(HA*(np.pi/180))*np.cos(delta*(np.pi/180))
    z = np.sin(delta*(np.pi/180))
    
    # rotate this along an axis going east-west.
    xhor = x*np.cos((90-Lat)*(np.pi/180))-z*np.sin((90-Lat)*(np.pi/180))
    yhor = y.copy()
    zhor = x*np.sin((90-Lat)*(np.pi/180))+z*np.cos((90-Lat)*(np.pi/180))
    
    # Find the h and AZ 
    angle_az = np.arctan2(yhor,xhor)*(180/np.pi) + 180
    angle_ele = np.arcsin(zhor)*(180/np.pi)
    
    
    return np.cos(np.deg2rad(90-angle_ele)), angle_ele, angle_az
    
    
    
#############################################################################
def isscalar(x):
    if isinstance(x, float) | isinstance(x, (int,np.integer) ):
        return True
    try:
        if x.size > 1:
            return False
    except:
        try:
            if len(x)==1:
                return True
        except:
            return False
    
    
    
#############################################################################
def spectral_albedo(skint, aod, cod, pw, u0, albedo0, sfc_type):

    from lib import NFLRTM as X
    (specalb, bbalb) = X.spectral_albedo(skint, aod, cod, pw, u0, albedo0, sfc_type)
    
    return specalb, bbalb
    
#############################################################################
def igbp_surface_albedo(sfc_type, u0, pw, tau):

    from lib import NFLRTM as X    
    (specalb, bbalb) = X.igbp_surface_albedo(sfc_type, u0, pw, tau)
    
    return specalb, bbalb
    
#############################################################################
#############################################################################
#############################################################################
# Functions to check inputs

# #--------------------------------------------------------------------------#
# def check_atmosphere(X, v, error, adjust, verbose):

#     # Dictionary defining valid ranges [min, max]
#     valid = {}
#     valid['temperature'] = [100.0001, 400.0]    
#     valid['sfc_temperature'] = [100.0001, 400.0]    
#     valid['water_vapor'] = [1.0001E-10, 0.5]    
#     valid['sfc_water_vapor'] = [1.0001E-10, 0.5]    
#     valid['ozone'] = [1.0001E-10, 1.0E-2]    
#     valid['sfc_ozone'] = [1.0001E-10, 1.0E-2]    
#     valid['skin_temperature'] = [100.0001, 500.0]    
#     valid['sfc_albedo'] =  [0.0, 1.0]    
#     valid['sfc_emissivity'] = [0.0, 1.0]    
#     valid['aer_tau'] = [0, 10]
    
#     if np.all(X == -1):
#         return X
    
#     ignore = np.isnan(X)
#     try:
#         ignore = ignore | X.mask
#     except:
#         pass
        
#     for i in range(2):
#         if i==0:
#             ind = (X < valid[v][i]) & (~ignore)
#         elif i==1:
#             ind = (X > valid[v][i]) & (~ignore)
#         else:
#             raise NotImplemented('Should not be here')
            
#         try:
#             ind = ind.filled(False)
#         except:
#             pass
        
#         if np.any(ind):
#             msg = 'Out-of-range value found in '+v
#             if error: raise ValueError(msg)                
#             if adjust:
#                 msg = msg+'... adjusting'
#                 X[ind] = valid[v][i]                    
#             if verbose: print(msg)
        
#     return X
    
# #--------------------------------------------------------------------------#
# def check_belowsfc(X, v, pressure_level, sfc_pressure,
#                         error, adjust, verbose):
    
#     if sfc_pressure > 0.0:
#         ind0 = X > 0.0
#         if len(X) == len(pressure_level):            
#             ind = pressure_level[ind0] > sfc_pressure
#         elif len(X) == (len(pressure_level)-1):
#             ind = pressure_level[1:][ind0] > sfc_pressure
#         else:
#             raise ValueError(v+' must be a level or layer variable')
            
            
        
#         if np.any(ind):
#             msg = 'Found level(s) below the surface pressure in '+v
#             if error: raise ValueError(msg)            
#             if adjust:
#                 msg = msg+'... removing'                
#                 X[ind] = np.ma.masked                    
#             if verbose: print(msg)
        
        
#     return X
    
# #==========================================================================#
# def check_cloud(cld_base_pres, cld_top_pres, cld_phase, cld_logtau,
#                 cld_lintau, cld_ice_diameter, cld_liquid_radius,
#                 pressure_level, sfcp, error=False, adjust=False, verbose=True):    
    
#     #---------------#
#     # Clouds completely outside profile (above or below)
#     min_p = np.sort(pressure_layer)[1]
#     ind = (cld_base_pres < min_p) |\
#           (cld_top_pres > sfcP)
#     ind = ind.filled(False)
    
#     msg = 'Clouds completely outside profile'
    
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... removing'
#             for v in cldvar:
#                 X[v][ind] = np.ma.masked                        
#         if verbose: print(msg)        
        
    
#     #---------------#
#     # Cloud base below the surface
#     ind = cld_base_pres > sfcP
#     ind = ind.filled(False)
        
#     msg = 'Cloud base below surface'
    
    
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... setting to surface presssure'
#             cld_base_pres[ind] = sfcP[ind]
#         if verbose: print(msg)
        
#     #---------------#
#     # Cloud top above TOA
#     min_p = np.sort(pressure_layer)[1]
#     ind = cld_top_pres < min_p
#     ind = ind.filled(False)
        
#     msg = 'Cloud top above TOA'
    
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... setting to TOA presssure'
#             cld_top_pres[ind] = min_p
#         if verbose: print(msg)
        
    
#     #---------------#
#     # Cloud base above cloud top
#     ind = cld_base_pres < cld_top_pres
#     ind = ind.filled(False)
    
#     msg = 'Cloud base above cloud top'
    
#     if np.any(ind):
        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... removing'
#             for v in cldvar:
#                 #X[v][ind] = X[v].fill_value
#                 X[v][ind] = np.ma.masked                        
#         if verbose: print(msg)        
        
    
#     #---------------#
#     #  Valid range (cloud fraction flag in different variable)
#     valid = OrderedDict()
#     valid['cld_logtau'] = np.log([1.0E-8, 1000.0])
#     valid['cld_lintau'] = [1.0E-8, 1000.0]
#     valid['cld_phase'] = [1.0, 2.0]
#     valid['cld_ice_diameter'] = [4.0, 250.0]
#     valid['cld_liquid_radius'] = [4.0, 30.0]
#     valid['cld_fraction'] = [0.0, 100.0]
        
    
#     for v in valid.keys():
    
#         bit_c_adj += 1
        
#         ignore = np.isnan(X[v])
#         try: ignore = ignore | X[v].mask
#         except: pass
            
#         for i in range(2):
#             if i==0:   ind = (X[v] < valid[v][i]) & (~ignore)
#             elif i==1: ind = (X[v] > valid[v][i]) & (~ignore)
#             else: raise NotImplemented('Should not be here')
            
#             msg = 'Out-of-range value found in '+v
            
#             if np.any(ind):                
#                 if error: raise ValueError(msg)                
#                 if adjust:
#                     msg = msg+'... adjusting'
#                     X[v][ind] = valid[v][i]                    
#                 if verbose: print(msg)
                
        
        
#     #-----------#
#     # Missing ice particle size
#     ind = (cld_phase > 1) & (cld_ice_diameter.mask)    
#     ind = ind.filled(False)
    
#     msg = 'Missing ice particle size'
        
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... setting to 60 microns'
#             cld_ice_diameter[ind] = 60.0
#         if verbose: print(msg)        
        
    
#     #-----------#
#     # Missing liquid particle size    
#     ind = (cld_phase < 2) & (cld_liquid_radius.mask)
#     ind = ind.filled(False)
    
#     msg = 'Missing liquid particle size'    
    
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... setting to 10 microns'
#             cld_liquid_radius[ind] = 10.0
#         if verbose: print(msg)        
        
        
#     #-----------#
#     # log(tau) > lin(tau)
#     ind = (np.exp(cld_logtau) > cld_lintau + 1.0E-8) &\
#           ~cld_logtau.mask
#     ind = ind.filled(False)
    
#     msg = 'Cloud log(tau) > lin(tau)'
    
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... fixing'
#             cld_lintau[ind] = np.exp(cld_logtau[ind]) + 1.01E-8
#         if verbose: print(msg)        
        
    
#     #-----------#
#     # Missing cloud layer properties
#     ind = np.zeros(cld_base_pres.shape,dtype='bool')
    
#     # Missing mixed phase cloud property
#     test = [X[v][...,None] for v in cldvar]
#     test = np.ma.concatenate( test, axis=-1)
    
#     ind[(cld_phase>1.0) & (cld_phase<2.0) &\
#         ~(np.all(test.mask==True,axis=-1) |\
#          np.all(test.mask==False,axis=-1)) ] = True
         
#     # Missing ice cloud property
#     test = [X[v][...,None] for v in cldvar if v is not 'cld_liquid_radius']
#     test = np.ma.concatenate( test, axis=-1)
    
#     ind[(cld_phase==2.0) &\
#         ~(np.all(test.mask==True,axis=-1) |\
#          np.all(test.mask==False,axis=-1)) ] = True
         
#     # Missing liquid cloud property
#     test = [X[v][...,None] for v in cldvar if v is not 'cld_ice_diameter']
#     test = np.ma.concatenate( test, axis=-1)
    
#     ind[(cld_phase==1.0) &\
#         ~(np.all(test.mask==True,axis=-1) |\
#          np.all(test.mask==False,axis=-1)) ] = True
    
#     msg = 'Missing cloud layer property'
    
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... removing'
#             for v in cldvar:
#                 #X[v][ind] = X[v].fill_value
#                 X[v][ind] = np.ma.masked                        
#         if verbose: print(msg)        
        
    
#     #-----------#
#     # Cloud fraction > 0, but no cloud properties
#     results = fill_missing_cld(X, error=error,
#                                 adjust=adjust, verbose=verbose)
                                
#     ind = results[1]
#     msg = results[2]
    
    
#     #-----------#
#     # Cloud fraction = 0, and cloud properties exits
#     try:
#         ind = ( (cld_fraction == 0.0) | (cld_fraction.mask)) &\
#               np.any(cld_base_pres.mask == False, axis=0)
#     except:
#         ind = (cld_fraction == 0.0)  &\
#               np.any(cld_base_pres.mask == False, axis=0)
         
 
#     ind = np.repeat(ind[None,...], ncldlyr, axis=0)
    
#     msg = 'Cloud properties exist when cloud fraction = 0'    
    
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             msg = msg+'... removing'
#             for v in cldvar:
#                 #X[v][ind] = X[v].fill_value
#                 X[v][ind] = np.ma.masked
#         if verbose: print(msg)        
        
    
#     #-----------#
#     # Total cloud fraction over 100%
#     tot_cf = np.sum(cld_fraction, axis=0)    
#     ind_bad_CFtot = tot_cf > 100.0    
#     ind = np.repeat(ind_bad_CFtot[None,...], ncldcond, axis=0)
    
#     if np.any(ind_bad_CFtot):
#         msg = 'Total coud fraction greater than 100%'
#         if error: raise ValueError(msg)       
#         if adjust and adjust_totCF:
#             msg = msg+'... adjusting'
#             with np.errstate(divide='ignore', invalid='ignore'):
#                 adj = np.repeat(99.99/tot_cf[None,...], ncldcond, axis=0)
#             cld_fraction[ind] = cld_fraction[ind] * adj[ind]
            
#         if verbose: print(msg)        
        
#     #-----------#
    
#     return cld_base_pres, cld_top_pres, cld_phase, cld_logtau,\
#         cld_lintau, cld_ice_diameter, cld_liquid_radius,\
#         pressure_level, sfcp
        
# #==========================================================================#
# def fill_missing_cld(X, X0=None, error=False, adjust=False, verbose=True):

#     cldvar = ['cld_base_pres','cld_top_pres','cld_phase','cld_logtau',
#               'cld_lintau','cld_ice_diameter','cld_liquid_radius    
    
#     ncldlyr = cld_top_pres.shape[0]
    
#     # Cloud fraction > 0, but no cloud properties
#     ind = (cld_fraction > 0.0) &\
#           np.all(cld_base_pres.mask == True, axis=0)
          
#     ind_frac = ind.copy()
#     ind = np.repeat(ind[None,...], ncldlyr, axis=0)
    
#     msg = 'Missing cloud properties when cloud fraction > 0'
    
#     if np.any(ind):        
#         if error: raise ValueError(msg)       
#         if adjust:
#             if X0 is None:
#                 msg = msg+'... removing'
#                 cld_fraction[ind_frac] = 0.0
#                 for v in cldvar: X[v][ind] = np.ma.masked
#             else:
#                 msg = msg+'... filling with X0 cloud properties'
#                 for v in cldvar: X[v][ind] =  X0[v][ind]
            
#         if verbose: print(msg)
        
#     return X, ind, msg
    
    
    
#############################################################################
#############################################################################
#############################################################################
def rt(\
       pressure_level,
       temperature,
       water_vapor,
       ozone,
       verbose = True,
       sfc_pressure = None,
       sfc_temperature  = None,
       sfc_water_vapor = None,
       sfc_ozone = None,
       skin_temperature = None,
       solar_constant = None,
       day_fraction = None,
       cos_solar_zenith = None,
       sfc_emissivity = None,
       sfc_albedo = None,
       sfc_albedo_g2str = None,
       cld_fraction = None,
       cld_base_pres = None,
       cld_top_pres = None,
       cld_phase = None,
       cld_tau = None,
       cld_lintau = None,
       cld_ice_diameter = None,
       cld_liquid_radius = None,
       aer_wavelength = None,
       aer_type = None,
       aer_tau = None,
       aer_vertdist = None,
       aer_vertdist_sfc = None,
       aer_rh = None,
       aer_sfc_rh = None,
       co2 = None,
       ch4 = None,
       n2o = None,
       cfc11 = None,
       cfc12 = None,
       hcfc22 = None,
       calc_noaer = False,
       calc_onlySW = False,
       calc_onlyLW = False, 
       wp_height = 2,
       solver_sw_hybrid = True,
       solver_method = 0,
       solver_sw_4str = False,
       solver_lw_4str = False,
       allow_cldfrac_gt1 = False,
       calc_pristine = False,
       rterror_warn = False,
       rt_printin = False,
       rt_printout = False,
       fill_value = -1.0E20,
       dp_tol = 1.0E-3,
       extra_calc_lvls = None,
       out_flux_toa = True,
       out_flux_sfc = False,
       out_flux_profile = False,
       out_flux_spectral = False,
       out_flux_cldcond = False):
    """
    Radiative transfer calculations using the NASA Fu-Liou model   
    """    
    
    if verbose:
        print(' ')
        
        
    #------------------------------------------------------------------------#
    # Check options
    #------------------------------------------------------------------------#
    if calc_onlySW and calc_onlyLW:
        raise ValueError('Both calc_onlySW and calc_onlyLW cannot be set to True')
    
    if verbose and calc_onlyLW and cos_solar_zenith and\
       (cos_solar_zenith > 0.0):
        print('NFLRTMpy: doing LW-only calculation, but cos_solar_zenith > 0')
        
    if fill_value > 0.0:
        raise ValueError('Fill value must be <= zero')
    
    #------------------------------------------------------------------------#
    # Atmospheric profiles (sfc->toa)
    #------------------------------------------------------------------------#
    
    # Set values from standard profiles definitions if strings given
    if isinstance(pressure_level, str):
        pressure_level = standard_profiles(pressure_level)[:,0]
        
    if isinstance(temperature, str):
        temperature = standard_profiles(temperature)[:,1]
        
    if isinstance(water_vapor, str):
        water_vapor = standard_profiles(water_vapor)[:,2]
        
    if isinstance(ozone, str):
        ozone = standard_profiles(ozone)[:,3]
        
    if not (len(pressure_level) == len(temperature) ==\
            len(water_vapor) == len(ozone)):
        raise ValueError('Length of pressure leves, temperature, water vapor and ozone profiles must be equal')
        
    
    #------------------------------------------------------------------------#
    # Surface values
    #------------------------------------------------------------------------#
    
    if (sfc_pressure is None) and\
       np.any([sfc_temperature, sfc_water_vapor, sfc_ozone]):
        raise ValueError('No surface pressure given, but other surface values exist')
        
    # Set surface values to -1 so they won't be inserted into the profile    
    if sfc_pressure is None:
        no_sfc = True
        sfc_temperature = -1
        sfc_water_vapor = -1
        sfc_ozone = -1
        sfc_pressure = -1
    else:
        no_sfc = False
        
        
    if skin_temperature is None:
        if sfc_temperature > 0:
            if verbose: print('NFLRTMpy: setting skin temperature = surface temperature')
            skin_temperature = sfc_temperature
        else:
            if verbose: print('NFLRTMpy: setting skin temperature = temperature of first level')
            skin_temperature = temperature[0]
            
            
    if not isscalar(sfc_pressure):
        raise ValueError('Surface pressure must be a single value')
    if not isscalar(sfc_temperature):
        raise ValueError('Surface temperature must be a single value')
    if not isscalar(sfc_water_vapor):
        raise ValueError('Surface water_vapor must be a single value')
    if not isscalar(sfc_ozone):
        raise ValueError('Surface ozone must be a single value')
    if not isscalar(skin_temperature):
        raise ValueError('Skin temperature must be a single value')
     
    # # Convert to numpy arrays
    # sfc_pressure = np.array(sfc_pressure)
    # sfc_temperature = np.array(sfc_temperature)
    # sfc_water_vapor = np.array(sfc_water_vapor)
    # sfc_ozone = np.array(sfc_ozone)
    # skin_temperature = np.array(skin_temperature)
    
    #------------------------------------------------------------------------#
    # Solar parameters 
    #------------------------------------------------------------------------#
    
    if solar_constant is None:
        if verbose: print('NFLRTMpy: setting solar constant to 1365 W/m^2')
        solar_constant = 1365.0
        
    if day_fraction is None:
        if verbose: print('NFLRTMpy: setting day fraction to 1')
        day_fraction = 1.0
        
    if cos_solar_zenith is None:
        if verbose: print('NFLRTMpy: setting cosine of the solar zenith angle to 1 (i.e. overhead sun)')
        cos_solar_zenith = 1.0
        
        
    # Adjust solar constant for earth sun distance
    #solar_constant = solar_constant * earth_sun_dis
    
    #------------------------------------------------------------------------#
    # Surface albedo / emissivity
    #------------------------------------------------------------------------#
    
    # Also option to specify spectral dependance
    
    # Number of bands
    nswb = 18
    nlwb = 14
    
    #---------------------------------#
    # Assumed values
    
    if sfc_emissivity is None:
        if verbose: print('NFLRTMpy: setting surface emissivity to 0.99')
        sfc_emissivity = [0.99]
        
    if sfc_albedo is None:
        if verbose: print('NFLRTMpy: setting surface albedo to 0.05')
        sfc_albedo = [0.05]
        
    if sfc_albedo_g2str is None:
        if verbose: print('NFLRTMpy: setting surface albedo for gamma 2-stream solver to true surface albedo')
        sfc_albedo_g2str = sfc_albedo
        
    #---------------------------------# 
    # Emissivity values from IGBP surface types:
    # negative -> IGBP index, or strings of surface type
    if isinstance(sfc_emissivity,int):
        sfc_emissivity = emissivity_igbp(np.abs(sfc_emissivity))
        
    if isinstance(sfc_emissivity,str):
        sfc_emissivity = emissivity_igbp(sfc_emissivity)
        
    #---------------------------------#    
    # Surface albedo from IGBP surface types:    
    # ***** Need to account for solar zenith angle when computing surface albedo 
    
    #---------------------------------#    
    # When only value is given, repeat it for each spectral band
    
    if isscalar(sfc_emissivity):
        sfc_emissivity = np.repeat(sfc_emissivity, nlwb).astype('float64')
    elif not len(sfc_emissivity) == nlwb:
        raise ValueError('Surface emissivity must be a single broadband value, or given for each '+\
                         str(nlwb)+' spectral bands')
                         
    if isscalar(sfc_albedo):
        sfc_albedo = np.repeat(sfc_albedo, nswb).astype('float64')
    elif not len(sfc_albedo) == nswb:
        raise ValueError('Surface albedo must be a single broadband value, or given for each '+\
                         str(nswb)+' spectral bands')
                         
    if isscalar(sfc_albedo_g2str):
        sfc_albedo_g2str = np.repeat(sfc_albedo_g2str, nswb).astype('float64')
    elif not len(sfc_albedo_g2str) == nswb:
        raise ValueError('Surface albedo for gamma 2-stream solver must be a single broadband value, or given for each '+\
                         str(nswb)+' spectral bands')
                         
                         
    # Repeat surface albedo for cloud and clear
    if sfc_albedo.ndim == 1:
        sfc_albedo = np.tile(  sfc_albedo, (2,1) ).T
    
    
    #------------------------------------------------------------------------#
    # Clouds
    #------------------------------------------------------------------------#
    
    if cld_fraction is None and\
       (cld_base_pres is not None or cld_top_pres is not None or\
        cld_phase is not None or cld_tau is not None or\
        cld_lintau is not None or cld_ice_diameter is not None or\
        cld_liquid_radius is not None):
        raise ValueError('No cloud fraction given, but other cloud properties exist')
        
    if cld_fraction is None:    
        # No clouds
        cld_fraction = np.zeros([1])
        cld_base_pres = np.zeros([1,1])
        cld_top_pres = np.zeros([1,1])
        cld_phase = np.zeros([1,1])
        cld_tau = np.zeros([1,1])
        cld_lintau = np.zeros([1,1])
        cld_ice_diameter = np.zeros([1,1])
        cld_liquid_radius = np.zeros([1,1])
        
    # Single cloud: convert scalers to numpy arrays
    if isscalar(cld_fraction):
        cld_fraction = np.zeros([1]) + cld_fraction
    if isscalar(cld_base_pres):
        cld_base_pres = np.zeros([1,1]) + cld_base_pres
    if isscalar(cld_top_pres):
        cld_top_pres = np.zeros([1,1]) + cld_top_pres
    if isscalar(cld_phase):
        cld_phase = np.zeros([1,1]) + cld_phase
    if isscalar(cld_tau):
        cld_tau = np.zeros([1,1]) + cld_tau
    if isscalar(cld_lintau):
        cld_lintau = np.zeros([1,1]) + cld_lintau
    if isscalar(cld_ice_diameter):
        cld_ice_diameter = np.zeros([1,1]) + cld_ice_diameter
    if isscalar(cld_liquid_radius):
        cld_liquid_radius = np.zeros([1,1]) + cld_liquid_radius
        
    if cld_lintau is None:
        if verbose: print('NFLRTMpy: setting cloud optical depth linear average to log average')
        cld_lintau = cld_tau
        
    if cld_ice_diameter is None and cld_fraction is not None:
        if verbose: print('NFLRTMpy: setting cloud ice particle diameter to 60 microns')
        cld_ice_diameter = np.zeros_like(cld_top_pres) + 60.0
        
    if cld_liquid_radius is None and cld_fraction is not None:
        if verbose: print('NFLRTMpy: setting cloud liquid particle radius to 8 microns')
        cld_liquid_radius = np.zeros_like(cld_top_pres) + 8.0
        
    if not (len(cld_fraction) == cld_base_pres.shape[1] == cld_top_pres.shape[1] == \
        cld_phase.shape[1] == cld_tau.shape[1] == cld_lintau.shape[1] == \
        cld_ice_diameter.shape[1] == cld_liquid_radius.shape[1]):
        raise ValueError('Number of cloud conditions mismatch')
        
    if not (cld_base_pres.shape[0] == cld_top_pres.shape[0] == \
        cld_phase.shape[0] == cld_tau.shape[0] == cld_lintau.shape[0] == \
        cld_ice_diameter.shape[0] == cld_liquid_radius.shape[0]):
        raise ValueError('Number of cloud layers mismatch')
        
    
    #------------------------------------------------------------------------#
    # Aerosols
    #------------------------------------------------------------------------#
    
    #     d'Almedia ( Types 1-3)
    #     'Tegin&Lacis ( Types 4-8)
    #     'OPAC Version 3.1a (Types 9-18)
    #     'Lacis 2004 (Types 19-25)
    atype_str =[\
               'maritime','continental','urban',
               'TL96 0.5 dust',
               'TL96 1.0 dust',
               'TL96 2.0 dust',
               'TL96 4.0 dust',
               'TL96 8.0 dust',
               'OPAC insoluble',
               'OPAC water soluble',
               'OPAC soot',
               'OPAC sea salt acc',
               'OPAC sea salt coarse',
               'OPAC dust nuc',
               'OPAC dust acc',
               'OPAC dust coarse',
               'OPAC dust trans',
               'OPAC sulfate',            
               'L04 0.5 dust',
               'L04 1.0 dust',
               'L04 2.0 dust',
               'L04 4.0 dust',
               'L04 8.0 dust',
               'L04 0.1-0.5 dust',
               'L04 0.5-5.0 dust']
    atype_str = [x.lower() for x in atype_str]
    
    
    if aer_tau is None:
        # No aerosol, but have to set this to a small number to avoid solver NaNs
        aer_tau = np.array([1.0E-10]).reshape(1,1)
        aer_wavelength = [0.55]
        aer_type = [2]
        
    if isscalar(aer_tau):
        # Only single aerosol tau given, reshape it to [wavelength x type]
        aer_tau = np.array(aer_tau).reshape(1,1)
        
    if aer_wavelength is None:
        if verbose: print('NFLRTMpy: setting aerosol optical depth wavelength to 0.55 microns')
        aer_wavelength = np.repeat(0.55,aer_tau.shape[0])
        
    if aer_type is None:
        if verbose: print("NFLRTMpy: Setting aerosol type(s) to Lacis' continental")
        aer_type = np.repeat(2,aer_tau.shape[1])
        
    # Convert aerosol types given as strings to integers
    if isinstance(aer_type,str): aer_type = [aer_type]
    if isinstance(aer_type, list):
        try:
            aer_type = [atype_str.index(x.lower())+1\
                        if isinstance(x,str) else x for x in aer_type]
        except ValueError:
            raise ValueError('Bad aerosol type string')
        
    if isscalar(aer_wavelength):
        # Only single aerosol tau given, reshape it to [wavelength]
        aer_wavelength = np.array(aer_wavelength).reshape(1)
        
    if isscalar(aer_type):
        # Only single aerosol type given, reshape it to [type]
        aer_type = np.array(aer_type).reshape(1)
        
    if aer_vertdist is None:
        if verbose: print('NFLRTMpy: Setting aerosol scale height(s) to 3 km')
        aer_vertdist = np.zeros([len(aer_wavelength), 1])
        aer_vertdist[:] = 3.0
        
    if isscalar(aer_vertdist):
        aer_vertdist = np.zeros([len(aer_wavelength), 1]) + aer_vertdist
        
        
    # No surface variables, so put in dummy variables
    if no_sfc:
        aer_vertdist_sfc = np.zeros_like(aer_wavelength) - 1.0
        aer_sfc_rh = [-1.0]
        
        
    # If aerosol vertical distribution is given as a scale height,
    # compute the profile (assuming the scale height of the atmosphere is 8km)
    if aer_vertdist.shape[1]==1:
        if no_sfc:
            z1 = 8.0 * np.log( pressure_level[0] /  pressure_level[:-1])
            z2 = 8.0 * np.log( pressure_level[0] /  pressure_level[1:])
        else:
            z1 = 8.0 * np.log( sfc_pressure /\
                               np.hstack((sfc_pressure, pressure_level))[:-1])
            z2 = 8.0 * np.log( sfc_pressure /\
                               np.hstack((sfc_pressure, pressure_level))[1:])
                               
        x = np.exp(-z2/aer_vertdist) - np.exp(-z1/aer_vertdist)
        x = 100*x/x.sum()
        
        if no_sfc:
            aer_vertdist = x
        else:
            aer_vertdist_sfc = x[:,0]
            aer_vertdist = x[:,1:]
            
            
    # Compute aer_rh / aer_sfc_rh if not given
    if aer_rh is None:
        aer_rh = mix2rh(water_vapor,temperature,pressure_level)
        aer_rh[aer_rh < 0.0] = 0.0
        aer_rh[aer_rh > 100.0] = 100.0
        
    if aer_sfc_rh is None:
        aer_sfc_rh = mix2rh(sfc_water_vapor,sfc_temperature,sfc_pressure)
        if aer_sfc_rh < 0.0:
            aer_sfc_rh = 0.0
        if aer_sfc_rh > 100.0:
            aer_sfc_rh = 100.0
        
        
        
    # Check dimensions
    if not aer_tau.shape[0] == len(aer_wavelength):
        raise ValueError('Aerosol wavelength dimension is invalid')
        
    if not aer_tau.shape[1] == len(aer_type):
        raise ValueError('Aerosol type dimension is invalid')
        
    # Check that length aer_rh matches temperature
    if not len(aer_rh) == len(temperature):
        raise ValueError('Aerosol RH profile length is invalid')
        
    # Check that length aer_rh matches number of layers
    if not aer_vertdist.shape[1] == len(temperature)-1:
        raise ValueError('Aerosol vertical profile length is invalid, must be specify for LAYERS')
        
        
    
    #------------------------------------------------------------------------#
    # Gases
    #------------------------------------------------------------------------#
    
    if co2 is None:
        if verbose: print('NFLRTMpy: setting CO2 to 360 ppmv')
        co2 = 360.0
        
    if ch4 is None:
        if verbose: print('NFLRTMpy: setting CH4 to 1.75 ppmv')
        ch4 = 1.75
        
    if n2o is None:
        if verbose: print('NFLRTMpy: setting N2O to 0.31 ppmv')
        n2o = 0.31
        
    if cfc11 is None:
        if verbose: print('NFLRTMpy: setting CFC11 to 0.268E-9 ppv')
        cfc11 = 0.268E-9
        
    if cfc12 is None:
        if verbose: print('NFLRTMpy: setting CFC12 to 0.503E-9 ppv')
        cfc12 = 0.503E-9
        
    if hcfc22 is None:
        if verbose: print('NFLRTMpy: setting CFC12 to 0.105E-9 ppv')
        hcfc22 = 0.105E-9
        
        
    # #----------------------------------------------------------------------#
    # # Check inputs
    # #----------------------------------------------------------------------#    
    
    # #*******************
    # input_error=True
    # input_adjust=False
    # input_verbose=True
    
    # # *** if all these are false, don't do any of the checks
    
    # temperature = check_atmosphere(temperature, 'temperature',
    #                                input_error,
    #                                input_adjust,
    #                                input_verbose)
    # sfc_temperature = check_atmosphere(sfc_temperature, 'sfc_temperature',
    #                                    input_error,
    #                                    input_adjust,
    #                                    input_verbose)
    # water_vapor = check_atmosphere(water_vapor, 'water_vapor',
    #                                input_error,
    #                                input_adjust,
    #                                input_verbose)
    # sfc_water_vapor = check_atmosphere(sfc_water_vapor, 'sfc_water_vapor',
    #                                    input_error,
    #                                    input_adjust,
    #                                    input_verbose)
    # ozone = check_atmosphere(ozone, 'ozone',
    #                          input_error,
    #                          input_adjust,
    #                          input_verbose)
    # sfc_ozone = check_atmosphere(sfc_ozone, 'sfc_ozone',
    #                              input_error,
    #                              input_adjust,
    #                              input_verbose)
    # skin_temperature = check_atmosphere(skin_temperature, 'skin_temperature',
    #                                     input_error,
    #                                     input_adjust,
    #                                     input_verbose)
    # sfc_albedo = check_atmosphere(sfc_albedo, 'sfc_albedo',
    #                               input_error,
    #                               input_adjust,
    #                               input_verbose)
    # sfc_emissivity = check_atmosphere(sfc_emissivity, 'sfc_emissivity',
    #                                   input_error,
    #                                   input_adjust,
    #                                   input_verbose)
    # aer_tau = check_atmosphere(aer_tau, 'aer_tau',
    #                            input_error,
    #                            input_adjust,
    #                            input_verbose)
    
    # # Check for values below the surface
    # temperature = check_belowsfc(temperature, 'temperature',
    #                              pressure_level, sfc_pressure,
    #                              error, adjust, verbose)
    # water_vapor = check_belowsfc(water_vapor, 'water_vapor',
    #                              pressure_level, sfc_pressure,
    #                              error, adjust, verbose)
    # ozone = check_belowsfc(ozone, 'ozone',
    #                        pressure_level, sfc_pressure,
    #                        error, adjust, verbose)
    # for i in range(aer_vertdist.shape[0]):
    #     aer_vertdist[i,:] = check_belowsfc(aer_vertdist[i,:], 'aer_vertdist',
    #                                        pressure_level, sfc_pressure,
    #                                        error, adjust, verbose)
                                           
                                           
    # # **** Check cloud properties
    # # cldvar = ['cld_base_pres','cld_top_pres','cld_phase','cld_logtau',
    # #           'cld_lintau','cld_ice_diameter','cld_liquid_radius']
              
    
    #----------------------------------------------------------------------#
    # Set the appropiate lib
    #----------------------------------------------------------------------#
    
    # See what libraries are availible
    LIBS = glob.glob('./lib/*.so')
    LIBS.sort()
    LIBS_NAME = [x.split('/')[-1].split('.')[0] for x in LIBS]
    print(LIBS_NAME)
    if len(LIBS)==1:
        # Only one, so use that one
        LIB = LIBS_NAME[0]
        
    else:
    
        # Parse the lib name to get the static array sizes
        sz = [x.split('_')[1] for x in LIBS_NAME]
        ncldconds = np.array([int(x[:3]) for x in sz])
        ncldlyrs = np.array([int(x[3:6]) for x in sz])
        nlvls = np.array([int(x[-3:]) for x in sz])
        
        # Array sizes of the inputs:
        ncldcond = len(cld_fraction)
        ncldlyr = cld_base_pres.shape[0]
        nlvl = len(pressure_level)
        
        # Static array combination to use:
        ncldcond0 = ncldconds[ncldcond <= ncldconds].min()
        ncldlyr0 = ncldlyrs[ncldlyr <= ncldlyrs].min()
        nlvl0 = nlvls[nlvl <= nlvls].min()
        
        ind = (ncldcond0 == ncldconds) & (ncldlyr0 == ncldlyrs) & \
              (nlvl0 == nlvls)
        LIB = np.array(LIBS_NAME)[ind][0]
        
    # Import it:
    print(LIB)
    NFLRTM = getattr(__import__('lib', fromlist=[LIB]), LIB)
    
    #----------------------------------------------------------------------#
    # Run radiative transfer and return results
    #----------------------------------------------------------------------#
    
    if extra_calc_lvls is None:
        extra_calc_lvls = np.zeros(1)
    
    # Turn off using ice aspect ratio (causes NaNs...could be an option later)
    ficear = False
    
    if calc_noaer or calc_pristine:
        calc_extra = True
    else:
        calc_extra = False
        
    (swdn,swup,lwdn,lwup,
     swdn_spec,swup_spec,lwdn_spec,lwup_spec,
     swhtr, lwhtr,
     swdn_cld,swup_cld,lwdn_cld,lwup_cld,swhtr_cld,lwhtr_cld,
     nlvlsfc, ierror_in, ierror_out,
     swnan_flux) = \
                   NFLRTM.rt_driver(ficear,pressure_level,
                                    n2o,cfc11,cfc12,hcfc22,
                                    solar_constant,
                                    aer_wavelength,aer_type,aer_tau,
                                    aer_vertdist,aer_vertdist_sfc,aer_rh,aer_sfc_rh,
                                    temperature,water_vapor,ozone,
                                    sfc_temperature,sfc_water_vapor,sfc_ozone,
                                    sfc_pressure,skin_temperature,co2,ch4,
                                    day_fraction,sfc_emissivity,sfc_albedo,
                                    sfc_albedo_g2str,cos_solar_zenith,
                                    cld_fraction,cld_base_pres,cld_top_pres,cld_phase,
                                    cld_tau,cld_lintau,cld_ice_diameter,
                                    cld_liquid_radius,
                                    extra_calc_lvls,fill_value,
                                    wp_height,solver_sw_hybrid,solver_method,
                                    solver_sw_4str,solver_lw_4str,
                                    allow_cldfrac_gt1,
                                    calc_extra, calc_onlySW, calc_onlyLW, 
                                    rt_printin, rt_printout, dp_tol)
    
    # Check if there were errors
    if ((ierror_in > 0) | (ierror_out > 0)):
        if not rterror_warn:
            raise RuntimeError('RT error '+str(ierror_in))
        else:
            warnings.warn('RT error '+str(ierror_in)+', fill values may be return in output')
            
    if verbose and (ierror_in == -1):
        print('RT found all fill values in profile: no RT performed')
        
    # Trim off surface values if none where used
    if no_sfc:
        swdn = swdn[...,1:]
        swup = swup[...,1:]
        lwdn = lwdn[...,1:]
        lwup = lwup[...,1:]
        swdn_spec = swdn_spec[...,1:]
        swup_spec = swup_spec[...,1:]
        lwdn_spec = lwdn_spec[...,1:]
        lwup_spec = lwup_spec[...,1:]
        swhtr = swhtr[...,1:]
        lwhtr = lwhtr[...,1:]
        
        swdn_cld = swdn_cld[...,1:]
        swup_cld = swup_cld[...,1:]
        lwdn_cld = lwdn_cld[...,1:]
        lwup_cld = lwup_cld[...,1:]
        swhtr_cld = swhtr_cld[...,1:]
        lwhtr_cld = lwhtr_cld[...,1:]
        
        nlvlsfc = nlvlsfc-1
        
        
    # Trim extra "layer" on heating rates
    swhtr = swhtr[...,1:]
    lwhtr = lwhtr[...,1:]
    swhtr_cld = swhtr_cld[...,1:]
    lwhtr_cld = lwhtr_cld[...,1:]
    
    # Mask out cloud fluxes when there is no cloud
    msk = np.repeat(cld_fraction[None,...]==0, swdn_cld.shape[0], axis=0)
    swdn_cld[msk] = fill_value
    swup_cld[msk] = fill_value
    lwdn_cld[msk] = fill_value
    lwup_cld[msk] = fill_value
    swhtr_cld[msk] = fill_value
    lwhtr_cld[msk] = fill_value
    
    
    # Keep only the calculations that were performed
    calc_keep = np.array([True, True, False, False])
    if calc_noaer:
        calc_keep[2] = True    
    if calc_pristine:
        calc_keep[3] = True
        
    swdn = swdn[calc_keep,...]
    swup = swup[calc_keep,...]
    lwdn = lwdn[calc_keep,...]
    lwup = lwup[calc_keep,...]
    swdn_spec = swdn_spec[calc_keep,...]
    swup_spec = swup_spec[calc_keep,...]
    lwdn_spec = lwdn_spec[calc_keep,...]
    lwup_spec = lwup_spec[calc_keep,...]
    swhtr = swhtr[calc_keep,...]
    lwhtr = lwhtr[calc_keep,...]
    
    swdn_cld = swdn_cld[calc_keep[[0,2]],...]
    swup_cld = swup_cld[calc_keep[[0,2]],...]
    lwdn_cld = lwdn_cld[calc_keep[[0,2]],...]
    lwup_cld = lwup_cld[calc_keep[[0,2]],...]
    swhtr_cld = swhtr_cld[calc_keep[[0,2]],...]
    lwhtr_cld = lwhtr_cld[calc_keep[[0,2]],...]
    
    
    # Set outputs to return
    out_flx = {}
    out_htr = {}
    
    out_htr['sw'] = swhtr
    out_htr['lw'] = lwhtr
    
    if out_flux_cldcond:
        out_htr['sw_cld'] = swhtr_cld
        out_htr['lw_cld'] = lwhtr_cld
        
    if out_flux_toa:
        out_flx['swdn_toa'] = swdn[...,-1].copy()
        out_flx['swup_toa'] = swup[...,-1].copy()
        out_flx['lwup_toa'] = lwup[...,-1].copy()
        
        if out_flux_spectral:
            out_flx['spectral_swdn_toa'] = swdn_spec[...,-1].copy()
            out_flx['spectral_swup_toa'] = swup_spec[...,-1].copy()
            out_flx['spectral_lwup_toa'] = lwup_spec[...,-1].copy()
        
        if out_flux_cldcond:
            out_flx['swdn_toa_cld'] = swdn_cld[...,-1].copy()
            out_flx['swup_toa_cld'] = swup_cld[...,-1].copy()
            out_flx['lwup_toa_cld'] = lwup_cld[...,-1].copy()        
        
    
    if out_flux_sfc:
        out_flx['swdn_sfc'] = swdn[...,nlvlsfc].copy()
        out_flx['swup_sfc'] = swup[...,nlvlsfc].copy()
        out_flx['lwup_sfc'] = lwup[...,nlvlsfc].copy()
        out_flx['lwdn_sfc'] = lwdn[...,nlvlsfc].copy()
        
        if out_flux_spectral:
            out_flx['spectral_swdn_sfc'] = swdn_spec[...,nlvlsfc].copy()
            out_flx['spectral_swup_sfc'] = swup_spec[...,nlvlsfc].copy()
            out_flx['spectral_lwup_sfc'] = lwup_spec[...,nlvlsfc].copy()
            out_flx['spectral_lwdn_sfc'] = lwdn_spec[...,nlvlsfc].copy()
        
        if out_flux_cldcond:
            out_flx['swdn_sfc_cld'] = swdn_cld[...,nlvlsfc].copy()
            out_flx['swup_sfc_cld'] = swup_cld[...,nlvlsfc].copy()
            out_flx['lwup_sfc_cld'] = lwup_cld[...,nlvlsfc].copy()
            out_flx['lwdn_sfc_cld'] = lwdn_cld[...,nlvlsfc].copy()
        
    if out_flux_profile:
        if no_sfc:
            z = slice(None)
        else:
            z = slice(1,None)
            
        out_flx['swdn'] = swdn[...,z]
        out_flx['swup'] = swup[...,z]
        out_flx['lwup'] = lwup[...,z]
        out_flx['lwdn'] = lwdn[...,z]
        
        if out_flux_spectral:
            out_flx['spectral_swdn'] = swdn_spec[...,z]
            out_flx['spectral_swup'] = swup_spec[...,z]
            out_flx['spectral_lwup'] = lwup_spec[...,z]
            out_flx['spectral_lwdn'] = lwdn_spec[...,z]
        
        if out_flux_cldcond:
            out_flx['swdn_cld'] = swdn_cld[...,z]
            out_flx['swup_cld'] = swup_cld[...,z]
            out_flx['lwup_cld'] = lwup_cld[...,z]
            out_flx['lwdn_cld'] = lwdn_cld[...,z]
            
    # Get rid of sw/lw fluxes if they weren't computed
    if calc_onlySW:
        s = 'sw'
    elif calc_onlyLW:
        s = 'lw'
    else:
        s = ''
        
    out_flx = dict([(k,v) for k,v in out_flx.items() if k.startswith(s)])    
    out_htr = dict([(k,v) for k,v in out_htr.items() if k.startswith(s)])    
    
    # Convert to masked arrays
    for v in out_flx.keys():
        out_flx[v] = np.ma.array(out_flx[v], fill_value=fill_value,
                                 mask=out_flx[v]==fill_value)
                                 
    for v in out_htr.keys():
        out_htr[v] = np.ma.array(out_htr[v], fill_value=fill_value,
                                 mask=out_htr[v]==fill_value)
        
    
    return out_flx, out_htr, ierror_in, ierror_out
    
    
