function [SWdn,SWup,LWdn,LWup,NETdt]=rad_trans_mark(zen,SST,Pres,Temp,Qv,Ozone,LWC,IWC,R_liq,R_ice,flg,varargin)
     if isempty(varargin) 
     co2=348;
     else
co2=varargin{1};
     end

% [SWdn,SWup,LWdn,LWup]=rad_trans(zen,SST,drop_conc,Pres,Temp,Qv,LWC,Ozone,flg):
% A (hopefully) relatively generic front-end for running
% the Fu-Liou radiative transfer scheme in matlab.  See
% rad_trans.txt for additional info.
% NOTE: flg=0 enables recompilation if number of levels in profile
% have changed. flg=1 skips recompilation checking (is faster).
% Created by Peter Caldwell - caldwep@atmos.washington.edu 1/13/04

% Editted by Mark Zelinka - mdz113@u.washington.edu 4/7/08

% THESE THINGS MUST BE IN THE DIRECTORY YOU ARE RUNNING THE FU LIOU CODE FROM: dynamic.f, jacket.f, and Makefile

try 
system('rm OUT.TXT');
catch
disp('there was no previous OUT.TXT')
end

%INITIALIZE
%----------------------------------------------
sz=max(size(Pres));
drop_conc=100; % completely irrelevant (never used but loaded into jacket anyway)

% the below file is used to trap inconsequential warnings about
% underflow.  It should be erased periodically so it doesn't get
% huge, but also read periodically to make sure more serious
% problems aren't being swept under the rug.
% delete rad_trans.log
fid=fopen('rad_trans.log','w');fclose(fid);

% if nargin<9
%   flg=0;
% end

%PAD LWC TO MAKE SAME SIZE AS OTHER INPUT PROFILES
%----------------------------------------------
% LWC=[LWC;0];
% Reff=zeros(size(LWC)); 
% Reff(LWC~=0 & Temp >= 263) = 10000;%10;    % Water droplets above 263K
% Reff(LWC~=0 & Temp < 263) = 10000;%30;     % Ice particles below 263K
% Reff=effective_radius_mark(LWC,drop_conc);

%CHECK FOR PROBLEMS SINCE FU SCHEME IS HARD TO DEBUG
%----------------------------------------------
% if max(size(Temp))~=sz
%   error('Pres and Temp differing sizes!');
% elseif max(size(Qv))~=sz
%   error('Pres and Qv differing sizes!');
% elseif max(size(LWC))==sz
%   error('LWC should have 1 less element than Pres!');
% elseif isempty(find(diff(Pres)>=0))==0
%   error('Pres must be monotonically decreasing!');
% end %if/elseif

%IF RECOMPILE NOT DISABLED (flg~=1), CHECK/RECOMPILE AS NEEDED
% flg should be 1 only if you know you are using the same number of levels each time you run this
if flg==0

    %EXTRACT PREVIOUSLY USED NUMBER OF LEVELS
%     fid=fopen('para.file','r');         %open file for reading
%     line=fgetl(fid);                    %read first line to string
%     dig=length(line)-34;                %nv has "dig" digits
%     old_sz=str2num(line(19:19+dig-1));  %Extract previously used
    %profile size
%     fclose(fid);

    %REWRITE para.file IF NECESSARY
    % If the size of the vectors used previously is different from what you are currently using, para.file must be rewritten:
%     if sz-1~=old_sz                      
        fid1=fopen('para.file','w');
        fprintf(fid1,'\tparameter ( nv = %d, nv1 = nv + 1 )\n',sz-1);
        fprintf(fid1,'\tparameter ( ndfs = nv, mdfs = nv + 1, ndfs4 = 4 * ndfs )\n');
        fprintf(fid1,'\tparameter ( mb = 18, mbs = 6, mbir = 12 )\n');
        fprintf(fid1,'\tparameter ( nc = 8 )\n');
        fprintf(fid1,'\tparameter ( icoln = 3 )\n');
        fclose(fid1);

        %RECOMPILE
        fprintf('*********************************\n');
        fprintf('REWRITING para.file, RECOMPILING.\n');
        fprintf('*********************************\n');

        system('make clean');               %Clear old fortran
        system('make');                     %recompile

%     end %if need to rewrite & recompile
end %if flg==0

%MAKE INPUT_PROFILE.TXT
%----------------------------------------------
%THE OLD "SAVE" ROUTINE IS APPARENTLY UNSTABLE IN VER. 7.

fid=fopen('CURRENT_PROFILE.TXT','w');
fprintf(fid,'%16.7f\n',co2);
fprintf(fid,'%16.7f\n',zen);
fprintf(fid,'%16.7f\n',SST);
fprintf(fid,'%16.7f\n',drop_conc);
for k=1:length(LWC);
  fprintf(fid,'%16.7e%16.7e%16.7e%16.7e%16.7e%16.7e%16.7e%16.7e\n',Pres(k),Temp(k),Qv(k),Ozone(k),LWC(k),IWC(k),R_ice(k),R_liq(k));
%   fprintf(fid,'%16.7e%16.7e%16.7e%16.7e%16.7e\n',Pres(k),Temp(k),Qv(k),Ozone(k),LWC(k));
end %FOR
fclose(fid);

%RUN RADIATION CODE
%----------------------------------------------
system('./main');

%READ OUTPUT
%----------------------------------------------
[Pres,SWdn,SWup,SWdT,LWdn,LWup,LWdT,NETdn,NETup,NETdt]=textread('OUT.TXT','%f %f %f %f %f %f %f %f %f %f');
